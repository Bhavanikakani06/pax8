# Azure Landing zone deployment V1.0.1
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurecaf"></a> [azurecaf](#requirement\_azurecaf) | ~>1.2.17 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 3.47.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | 3.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurecaf"></a> [azurecaf](#provider\_azurecaf) | ~>1.2.17 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.47.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurecaf_name.diagnostics](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.diagnosticspe](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.disk_encryption](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.keykvstore](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.kvstore](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.log_analytics](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.network_watcher](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.pekvstore](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.recovery_vault](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.rg](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.subnet_name](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurecaf_name.vnet_name](https://registry.terraform.io/providers/aztfmod/azurecaf/latest/docs/resources/name) | resource |
| [azurerm_backup_policy_vm.umbrellarBackup](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/backup_policy_vm) | resource |
| [azurerm_disk_encryption_set.disk_encryption](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/disk_encryption_set) | resource |
| [azurerm_key_vault.kvstore](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/key_vault) | resource |
| [azurerm_key_vault_access_policy.disk_encryption](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_access_policy.kvstore](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.keykvstore](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/key_vault_key) | resource |
| [azurerm_log_analytics_workspace.log_analytics](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/log_analytics_workspace) | resource |
| [azurerm_monitor_diagnostic_setting.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/network_security_group) | resource |
| [azurerm_network_watcher.netwatcher](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/network_watcher) | resource |
| [azurerm_network_watcher_flow_log.nw_flow](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_private_endpoint.diagnosticspe](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/private_endpoint) | resource |
| [azurerm_recovery_services_vault.recovery_vault](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/recovery_services_vault) | resource |
| [azurerm_resource_group.rg](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.backup](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.contributor](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.disk_encryption](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/role_assignment) | resource |
| [azurerm_security_center_auto_provisioning.example](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_subscription_pricing.tier](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_storage_account.diagnostics](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/storage_account) | resource |
| [azurerm_subnet.subnet](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.subnet_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subscription_policy_assignment.example](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/subscription_policy_assignment) | resource |
| [azurerm_subscription_policy_assignment.policy](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/subscription_policy_assignment) | resource |
| [azurerm_virtual_network.vnet](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/resources/virtual_network) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/data-sources/client_config) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/3.47.0/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_company_short_name"></a> [company\_short\_name](#input\_company\_short\_name) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `any` | n/a | yes |
| <a name="input_environment_short_name"></a> [environment\_short\_name](#input\_environment\_short\_name) | n/a | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `any` | n/a | yes |
| <a name="input_location_short_name"></a> [location\_short\_name](#input\_location\_short\_name) | n/a | `any` | n/a | yes |
| <a name="input_security_center_resource_types"></a> [security\_center\_resource\_types](#input\_security\_center\_resource\_types) | List of security center resource types to configure | `list(string)` | <pre>[<br>  "VirtualMachines",<br>  "AppServices",<br>  "KeyVaults",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns",<br>  "Containers",<br>  "OpenSourceRelationalDatabases"<br>]</pre> | no |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | n/a | `any` | n/a | yes |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_akv_id"></a> [akv\_id](#output\_akv\_id) | n/a |
| <a name="output_azurerm_key_vault_access_policy"></a> [azurerm\_key\_vault\_access\_policy](#output\_azurerm\_key\_vault\_access\_policy) | n/a |
| <a name="output_diagnostics_id"></a> [diagnostics\_id](#output\_diagnostics\_id) | n/a |
| <a name="output_disk_encryption_id"></a> [disk\_encryption\_id](#output\_disk\_encryption\_id) | n/a |
| <a name="output_recovery_vault_name"></a> [recovery\_vault\_name](#output\_recovery\_vault\_name) | n/a |
| <a name="output_umbrellarBackup"></a> [umbrellarBackup](#output\_umbrellarBackup) | n/a |


## Diagram

![terraform-azure-landing-zone-deployment v1 0 1](https://user-images.githubusercontent.com/106001069/225260975-73686e29-fc8f-47dd-8972-3c7db8064d9f.png)
