import logging
import azure.functions as func
from python_terraform import *

def main(req: func.HttpRequest) -> func.HttpResponse:
    # Initialize Terraform and execute commands
    tf = Terraform(working_dir='python_tf_app')
    tf.fmt(diff=True)
    tf.init()

    variables = {
        'subscription_id': 'b6bc174f-3ea1-481b-8d2a-614f2f2e464b'
        # Add more variables as needed
    }
    # Pass variables to plan and apply
    tf.plan(var=variables)
    tf.apply(skip_plan=True, var=variables)

    return func.HttpResponse("Deployment completed", status_code=200)
