from python_terraform import *

# Initialize Terraform and execute commands
print("Python HTTP trigger function processed a request.")

# GitHub repository details
subscription_id = os.environ.get("SUBSCRIPTION_ID")
client_secret = os.environ.get("CLIENT_SECRET")

tf = Terraform(working_dir='python_tf_app')
tf.fmt(diff=True)
tf.init()
variables = {
    'subscription_id': subscription_id,
    'client_secret':  client_secret
}
# Pass variables to plan and apply
tf.plan(var=variables)
tf.apply(skip_plan=True, var=variables)
