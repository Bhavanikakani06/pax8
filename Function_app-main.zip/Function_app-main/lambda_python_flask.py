import json
from python_terraform import *
import platform
import requests
import zipfile

def lambda_handler(event, context):
    terraform_version = '1.7.1'
    install_path = "/usr/local/bin"

    download_path = download_terraform(terraform_version)
    install_terraform(download_path, install_path)
    print("Terraform installed successfully!")
    
    # TODO implement
    tf = Terraform(working_dir='python_tf_app')
    tf.init()
    print(tf.plan(var=variables))
    variables = {
        'subscription_id': 'b6bc174f-3ea1-481b-8d2a-614f2f2e464b'
        # Add more variables as needed
    }
    # Pass variables to plan and apply
    tf.plan(var=variables)
    tf.apply(skip_plan=True, var=variables)
    return {
        'statusCode': 200,
        'body': json.dumps('Deployment completed!')
    }

def download_terraform(version):
    base_url = "https://releases.hashicorp.com/terraform"
    download_url = f"{base_url}/{version}/terraform_{version}_{platform.system().lower()}_{platform.machine().lower()}.zip"
    download_path = f"/tmp/terraform_{version}.zip"
    
    print(f"Downloading Terraform {version}...")
    response = requests.get(download_url)
    with open(download_path, 'wb') as f:
        f.write(response.content)
    
    return download_path

def install_terraform(download_path, install_path):
    print("Installing Terraform...")
    with zipfile.ZipFile(download_path, 'r') as zip_ref:
        zip_ref.extractall(install_path)
