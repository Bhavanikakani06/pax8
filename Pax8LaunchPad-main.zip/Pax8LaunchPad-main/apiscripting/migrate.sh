#!/bin/bash

# Set your organization, project, and API version
ORG="pax8"
PROJECT="Enterprise-Services-Team"
api_version="6.0"


#epic_name="Azure Devops API Test"
feature_name="Migration by launchpad"
epic_json='[
    {
        "op": "add",
        "path": "/fields/System.Title",
        "value": "'"$EPIC_NAME"'"
    }
]'
epic_response=$(curl -X POST -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/\$Epic?api-version=6.0 -d "$epic_json")
epic_id=$(echo $epic_response | jq -r '.id')
echo "$epic_response"


feature_json='[
    {
        "op": "add",
        "path": "/fields/System.Title",
        "value": "'"$feature_name"'"
    },
    {
        "op": "add",
        "path": "/relations/-",
        "value": {
            "rel": "System.LinkTypes.Hierarchy-Reverse",
            "url": "https://dev.azure.com/'$ORG'/'$PROJECT'/_apis/wit/workItems/'$epic_id'",
            "attributes": {
                "comment": "Linking Feature to Epic"
            }
        }
    }
]'
feature_response=$(curl -X POST -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/\$Feature?api-version=6.0 -d "$feature_json")
feature_id=$(echo $feature_response | jq -r '.id')
echo "$feature_response"
echo "Items created and linked successfully."


pbi1_name="Discovery phase"
pbi2_name="Migration"
pbi1_json='[
    {
        "op": "add",
        "path": "/fields/System.Title",
        "value": "'"$pbi1_name"'"
    },
    {
        "op": "add",
        "path": "/relations/-",
        "value": {
            "rel": "System.LinkTypes.Hierarchy-Reverse",
            "url": "https://dev.azure.com/'$ORG'/'$PROJECT'/_apis/wit/workItems/'$feature_id'",
            "attributes": {
                "comment": "Linking PBI 1 to Feature"
            }
        }
    }
]'

pbi2_json='[
    {
        "op": "add",
        "path": "/fields/System.Title",
        "value": "'"$pbi2_name"'"
    },
    {
        "op": "add",
        "path": "/relations/-",
        "value": {
            "rel": "System.LinkTypes.Hierarchy-Reverse",
            "url": "https://dev.azure.com/'$ORG'/'$PROJECT'/_apis/wit/workItems/'$feature_id'",
            "attributes": {
                "comment": "Linking PBI 2 to Feature"
            }
        }
    }
]'

pbi1_response=$(curl -X POST -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/\$Product%20Backlog%20Item?api-version=6.0 -d "$pbi1_json")
pbi2_response=$(curl -X POST -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/\$Product%20Backlog%20Item?api-version=6.0 -d "$pbi2_json")
pbi_id1=$(echo $pbi1_response | jq -r '.id')
pbi_id2=$(echo $pbi2_response | jq -r '.id')
echo "$pbi1_response"
echo "$pbi2_response"

declare -A tasks=(
    ["kickoff meeting"]="$pbi_id1:1.5"
    ["Arrange access to the team"]="$pbi_id1:0.25"
    ["Assist Partner to setup Discovery appliance"]="$pbi_id1:1"
    ["Run the assessment and share it with partner"]="$pbi_id1:1"
    ["Assist partner to install MMA and dependency agent as part of Assessment"]="$pbi_id1:1"
    ["Prepare/share the Design based on Assessment to Partner/Engineer"]="$pbi_id1:2"
    ["Deploy landing zone via LaunchPad"]="$pbi_id2:0.5"
    ["Deploy other azure resources not included in LaunchPad"]="$pbi_id2:0.5"
    ["Assist partner to setup Replication appliance OR Assist partner to setup mobility service agent, if migrating physical server"]="$pbi_id2:2"
    ["Assist partner for Test Migration deployment"]="$pbi_id2:1"
    ["Assist partner for Migration deployment"]="$pbi_id2:1"
    ["Migration cutover"]="$pbi_id2:2"
)


for task in "${!tasks[@]}"; do
    IFS=':' read -r -a array <<< "${tasks[$task]}"
    task_name=$task
    pbi_id=${array[0]}
    effort=${array[1]}

    
    task_json='[
        {
            "op": "add",
            "path": "/fields/System.Title",
            "value": "'"$task_name"'"
        },
        {
            "op": "add",
            "path": "/fields/Custom.OriginalEffort",
            "value": "'"$effort"'"
        },
        {
            "op": "add",
            "path": "/relations/-",
            "value": {
                "rel": "System.LinkTypes.Hierarchy-Reverse",
                "url": "https://dev.azure.com/'$ORG'/'$PROJECT'/_apis/wit/workItems/'$pbi_id'",
                "attributes": {
                    "comment": "Linking Task to PBI"
                }
            }
        }
    ]'

    # Send the request
    response=$(curl -s -X POST -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/\$Task?api-version=6.0 -d "$task_json")

    task_id=$(echo $response | jq -r '.id')  
     if [[ $pbi_id == $pbi_id1 ]]; then
        pbi_task_ids1+=($task_id)
    elif [[ $pbi_id == $pbi_id2 ]]; then
        pbi_task_ids2+=($task_id)
    fi
    echo "Created task '$task_name' with ID $task_id and effort $effort"
    echo "$response"

done

echo ${pbi_task_ids1[@]}
echo ${pbi_task_ids2[@]}

 total_effort=0
# Loop over the PBIs
for ids in "${pbi_task_ids1[@]}"; do
    # Initialize a variable to hold the total effort
     
       #expand="Relations"
       #response1=$(curl -s -X GET -u :$PAT "https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$pid?api-version=6.0&$expand=$expand")  


    # Extract the task IDs from the response1
    
        #task_ids=$(echo $response1 | jq -r 'if .relations != null then .relations[] | select(.rel=="System.LinkTypes.Hierarchy-Forward") | .url | split("/") | last else empty end')
        echo "After assignment, task_ids: $pbi_task_ids1"

    # Loop over the task IDs
    #for ids in "${task_ids[@]}"; do
        # Get the task
        echo $ids
        response2=$(curl -s -X GET -u :$PAT "https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$ids?api-version=6.0")

        # Extract the effort from the task
        taskeffort=$(echo $response2 | jq -r '.fields["Custom.OriginalEffort"]')

# Check if effort is a valid number
       if [[ $taskeffort =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
    # Add the effort to the total effort
          total_effort=$(echo "$total_effort + $taskeffort" | bc)
       else
          echo "Invalid effort value: $taskeffort"
        fi
    #done

    # Create the JSON payload to update the PBI
    pbi_json='[
        {
            "op": "add",
            "path": "/fields/Microsoft.VSTS.Scheduling.Effort",
            "value": "'"$total_effort"'"
        }
    ]'

    # Send the request to update the PBI
    response3=$(curl -s -X PATCH -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$pbi_id1?api-version=6.0 -d "$pbi_json")

    # Print the response3
    echo "$response3"
done

total_effort2=0
for pids in "${pbi_task_ids2[@]}"; do
    # Initialize a variable to hold the total effort
     
       #expand="Relations"
       #response1=$(curl -s -X GET -u :$PAT "https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$pid?api-version=6.0&$expand=$expand")  


    # Extract the task IDs from the response1
    
        #task_ids=$(echo $response1 | jq -r 'if .relations != null then .relations[] | select(.rel=="System.LinkTypes.Hierarchy-Forward") | .url | split("/") | last else empty end')
        echo "After assignment, task_ids: $pbi_task_ids2"

    # Loop over the task IDs
    #for ids in "${task_ids[@]}"; do
        # Get the task
        echo $pids
        response4=$(curl -s -X GET -u :$PAT "https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$pids?api-version=6.0")

        # Extract the effort from the task
        taskeffort2=$(echo $response4 | jq -r '.fields["Custom.OriginalEffort"]')

# Check if effort is a valid number
       if [[ $taskeffort2 =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
    # Add the effort to the total effort
          total_effort2=$(echo "$total_effort2 + $taskeffort2" | bc)
       else
          echo "Invalid effort value: $taskeffort2"
        fi
    #done

    # Create the JSON payload to update the PBI
    pbi_json='[
        {
            "op": "add",
            "path": "/fields/Microsoft.VSTS.Scheduling.Effort",
            "value": "'"$total_effort2"'"
        }
    ]'

    # Send the request to update the PBI
    response3=$(curl -s -X PATCH -H "Content-Type: application/json-patch+json" -u :$PAT https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$pbi_id2?api-version=6.0 -d "$pbi_json")

    # Print the response3
    echo "$response3"
done


#sleep 300
#delete_work_item() {
#    local id=$1
#    local response=$(curl -X DELETE -u :$PAT \
#        https://dev.azure.com/$ORG/$PROJECT/_apis/wit/workitems/$id?api-version=6.0)
#    echo $response
#}
#delete_work_item $epic_id
#delete_work_item $feature_id
#delete_work_item $pbi_id1
#delete_work_item $pbi_id2
#for task_name in "${!tasks[@]}"; do
#    pbi_id=${tasks[$task_name]}
#    delete_work_item $pbi_id
    
#done